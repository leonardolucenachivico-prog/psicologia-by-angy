# Psicología by Angy — Sitio estático
Este paquete contiene los archivos listos para publicar en la web.

## Estructura
- `index.html` — Página principal
- `styles.css` — Estilos
- `logo.jpg` — Logo (cabecera y portada)
- `foto_portada.jpg` — Foto principal (hero)
- `foto_sobre_mi.jpg` — Foto sección Sobre mí

---

## Publicar en **Netlify** (muy fácil)
1. Ir a https://app.netlify.com/drop
2. Arrastrar y soltar **toda la carpeta** `angy_site_deploy` (o el ZIP descomprimido).
3. Netlify asignará una URL pública automática. Podés cambiar el nombre del sitio en *Site settings → Change site name*.
4. Para usar dominio propio: *Domain settings → Add domain → Connect domain*.

## Publicar en **GitHub Pages**
1. Crear un repositorio nuevo en GitHub (por ej. `psicologia-by-angy`).
2. Subir **todos** los archivos de esta carpeta al repo (root).
3. Ir a *Settings → Pages* y elegir:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main` y carpeta `/ (root)`
4. Guardar. En 1–2 minutos tendrás la URL: `https://TU-USUARIO.github.io/psicologia-by-angy/`

## Opcional
- Para ícono de pestaña (favicon), duplicá `logo.jpg` como `favicon.png` y agregá en `<head>`:
  `<link rel="icon" type="image/png" href="favicon.png">`
- Para cambiar WhatsApp: editá el link `https://wa.me/5491124284306` en `index.html`.
